$(function () {
 
    $("#youxiang").blur(checkEmail);
    $("#fname").blur(checkFname);
    $("#pwd").blur(checkPass);
    $("#repwd").blur(checkRePass);

   
   
    $("form").submit(function () {
   
        var flag = true;   
        if (!checkEmail()) flag = false;
        if (!checkFname()) flag = false;
        if (!checkRePass()) flag = false;
        if (!checkPass()) flag = false;


   
        return flag;
    });
   });
   // 验证邮箱
           function checkEmail(){
               var $email = $("#youxiang").val();
               var $divID = $("#DivEmail");
               $divID.html("");
               if ($email == "") {
                return false;
            }
            return true;
           }
   // 验证昵称
   
        function checkFname() {
            var $fname = $("#fname");
            var $divID = $("#DivFname");
            $divID.html("");
            if ($fname.val() == "") {
                return false;
            }
    
            return true;
        }

        //验证密码
     function checkPass() {
        var $pwd = $("#pwd");
        var $divID = $("#DivPwd");
        $divID.html("");
        if ($pwd.val() == "") {
            return false;
        }
        if ($pwd.val().length < 6) {
            return false;
        }
        return true;
    }
    //验证重复密码
    function checkRePass() {
        var $pwd = $("#pwd"); 
        var $repwd = $("#repwd"); 
        var $divID = $("#DivRepwd");
        $divID.html("");
        if ($pwd.val() != $repwd.val()) {
            return false;
        }
        return true;
    }
