        ///轮播
        $(function() {
            $('#toright').hover(function() {
                $("#toleft").hide()
            }, function() {
                $("#toleft").show()
            })
            $('#toleft').hover(function() {
                $("#toright").hide()
            }, function() {
                $("#toright").show()
            })
        })
        
        var t;
        var index = 0;
        /////自动播放
        t = setInterval(play, 1000)
        
        function play() {
            index++;
            if (index > 4) {
                index = 0
            }
            // console.log(index)
            $("#lunbobox ul li").eq(index).css({
                "background": "#999",
                "border": "1px solid #ffffff"
            }).siblings().css({
                "background": "#cccccc",
                "border": ""
            })
        
            $(".lunbo a ").eq(index).fadeIn(1000).siblings().fadeOut(1000);
        };
		
        $("#lunbobox ul li").click(function() {
      
            $(this).css({
                "background": "#999",
                "border": "1px solid #ffffff"
            }).siblings().css({
                "background": "#cccccc"
            })
            var index = $(this).index(); 
            // console.log(index);
            $(".lunbo a ").eq(index).fadeIn(1000).siblings().fadeOut(1000);
        });
        
        $("#toleft").click(function() {
            index--;
            if (index <= 0)
            {
                index = 4
            }
            console.log(index);
            $("#lunbobox ul li").eq(index).css({
                "background": "#999",
                "border": "1px solid #ffffff"
            }).siblings().css({
                "background": "#cccccc"
            })
        
            $(".lunbo a ").eq(index).fadeIn(1000).siblings().fadeOut(1000); 
        });
        
        $("#toright").click(function() {
            index++;
            if (index > 4) {
                index = 0
            }
            console.log(index);
            $(this).css({
                "opacity": "0.5"
            })
            $("#lunbobox ul li").eq(index).css({
                "background": "#999",
                "border": "1px solid #ffffff"
            }).siblings().css({
                "background": "#cccccc"
            })
            $(".lunbo a ").eq(index).fadeIn(1000).siblings().fadeOut(1000);
        });
        $("#toleft,#toright").hover(function() {
                $(this).css({
                    "color": "black"
                })
            },
            function() {
                $(this).css({
                    "opacity": "0.3",
                    "color": ""
                })
            })
        ///
        
        $("#lunbobox ul li,.lunbo a img,#toright,#toleft ").hover(

            function() {
                $('#toright,#toleft').show()
                clearInterval(t);
        
            },
            function() {
                //alert('aaa')
                t = setInterval(play, 3000)
        
                function play() {
                    index++;
                    if (index > 4) {
                        index = 0
                    }
                    $("#lunbobox ul li").eq(index).css({
                        "background": "#999",
                        "border": "1px solid #ffffff"
                    }).siblings().css({
                        "background": "#cccccc"
                    })
                    $(".lunbo a ").eq(index).fadeIn(1000).siblings().fadeOut(1000);
                }
            })


var dome; //全局变量
var timer; //定时器变量
window.onload = function()
{
	dome = document.getElementById("dome");
	var dome1 = document.getElementById("dome1");
	var dome2 = document.getElementById("dome2");
	dome1.style.height = dome.offsetHeight + "px";
	dome2.style.height = dome.offsetHeight + "px";
	dome2.innerHTML = dome1.innerHTML;
	dome.onmouseover = function(){
							window.clearInterval(timer);
						}
	dome.onmouseout = function(){
							timer = window.setInterval("start2()",40);
						}
	//定时器
	timer = window.setInterval("start2()",40);
}
function start2()
{
	if(dome.scrollTop == dome.offsetHeight)
	{
		dome.scrollTop = 0;
	}else
	{
		dome.scrollTop++;
	}
}