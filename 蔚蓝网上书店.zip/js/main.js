//表单验证
$(function(){
				
			
				
    $('#formRegister').submit(function(){
        var flag=true;
    
        if(!pass()){
            flag=false;
        }
    
        if(!email()){
            flag=false;
        }
        return flag;
})



$('#pass').blur(pass);
$('#email').blur(email);


        
function pass(){
//密码验证
var $pass=$('#pass').val();
if($pass==''){
    $('#DivPwd').html("密码不能为空")
    return false;
}else{
    $('#DivPwd').html("")
}
if($pass.length<6){
    $('#DivPwd').html("密码必须等于或者大于6个字符")
    return false;
}
return true;
}

function email(){
//邮箱验证
var $email=$('#email').val()
if($email==''){
    $('#DivEmail').html("邮箱不能为空")
    return false;
}else{
    $('#DivEmail').html("")
}
if($email.indexOf("@")==-1 || $email.indexOf(".")==-1){
    $('#DivEmail').html("Email格式不正确,必须包含@.")
    return false;
}
return true;
}
})


//鼠标移入移除事件
$(function(){
    $("#email").mouseover(function(){
        $("#email").css("background-color","#f1ffde")
    })
    $("#email").mouseout(function(){
        $("#email").css("background-color","#ffffff")
    })
    $("#pass").mouseover(function(){
        $("#pass").css("background-color","#f1ffde")
    })
    $("#pass").mouseout(function(){
        $("#pass").css("background-color","#ffffff")
    })
})